from django import forms
from django.forms import fields



class Register(forms.Form):
    name=forms.CharField(max_length=50,label="User",widget=forms.TextInput(attrs={"class":"form-control","placeholder":"Enter Name"}))
    email=forms.EmailField(max_length=50,label="Email",widget=forms.EmailInput(attrs={"class":"form-control","placeholder":"Enter Mail"}))
    password=forms.CharField(max_length=50,label="Password",widget=forms.PasswordInput(attrs={"class":"form-control","placeholder":"Enter Password"}))
    rpassword=forms.CharField(max_length=50,label="Re-Password",widget=forms.PasswordInput(attrs={"class":"form-control","placeholder":"Confirm Password"}))

class Login(forms.Form):
    email=forms.EmailField(max_length=50,required=False,label="Email",widget=forms.EmailInput(attrs={"class":"form-control","placeholder":"Enter Email"}))
    password=forms.CharField(max_length=50,label="Password",widget=forms.PasswordInput(attrs={"class":"form-control","placeholder":"Enter password"}))

    
















# def clean(self):
#     cleaned_data = super().clean()
#     valpwd = self.cleaned_data['password']
#     valrpwd = self.cleaned_data['rpassword']
#     if valpwd != valrpwd:
#         raise forms.ValidationError('password does not match')